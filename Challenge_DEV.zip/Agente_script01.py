#! /usr/bin/python3

def infosystem():

	import platform as pl

	perfil_so=['architecture', 'linux_distribution', 'mac_ver','machine','node', 'platform','processor','python_build','release','system','uname','version',]

	for perfil in perfil_so:
		if hasattr(pl, perfil):
			salida=print('%s: %s' % (perfil, getattr(pl,perfil)()))
	return salida

archivo = open("infosystem01.txt","w")
archivo.write(str(infosystem()))
archivo.close()

#from wurlitzer import pipes
#stdout=out.read()
#archivo=open("infoserver.csv","e")
#archivo.write((stdout))
#archivo.close()


